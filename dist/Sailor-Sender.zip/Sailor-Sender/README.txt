Для того, щоб додаток працював правильно, необхідно перейти за посиланням: 
"https://myaccount.google.com/lesssecureapps?rapt=AEjHL4Pse9JXYSbtdOgGLE3QZ8AXg2BgwMABrgCfXHjdlZPX66rAa5aMpVdEiitQA3WAHIkPPn0Bnq5sGHO1rPBaJbi-fdPviQ"
Після чого дозволити використання аккаунту небезпечним додаткам.

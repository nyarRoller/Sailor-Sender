n = int(input())


f

# for i in range(n)


# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'SelectObj.ui'
#
# Created by: PyQt5 UI code generator 5.14.2
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_SelectObl(object):
    def setupUi(self, SelectObl):
        SelectObl.setObjectName("SelectObl")
        SelectObl.resize(972, 770)
        SelectObl.setMinimumSize(QtCore.QSize(972, 770))
        SelectObl.setMaximumSize(QtCore.QSize(972, 770))
        self.Vintis = QtWidgets.QPushButton(SelectObl)
        self.Vintis.setGeometry(QtCore.QRect(130, 130, 331, 31))
        self.Vintis.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.Vintis.setStyleSheet("QPushButton {\n"
"background-color: #333333;\n"
"border-radius: 10px;\n"
"\n"
"font-family: Poppins-Medium;\n"
"font-size: 16px;\n"
"color: #fff;\n"
"line-height: 1.2;\n"
"}\n"
"QPushButton::before {\n"
"  content: \"\";\n"
"  display: block;\n"
"  position: absolute;\n"
"  z-index: -1;\n"
"  width: 100%;\n"
"  height: 100%;\n" 
"  border-radius: 10px;\n"
"  top: 0;\n"
"  left: 0;\n"
"  background: #a64bf4;\n"
"  background: -webkit-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: -o-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: -moz-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  opacity: 0;\n"
"  -webkit-transition: all 0.4s;\n"
"  -o-transition: all 0.4s;\n"
"  -moz-transition: all 0.4s;\n"
"  transition: all 0.4s;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"  background-color: #545454;\n"
"}\n")
        self.Vintis.setObjectName("Vintis")
        self.Volinsk = QtWidgets.QPushButton(SelectObl)
        self.Volinsk.setGeometry(QtCore.QRect(130, 170, 331, 31))
        self.Volinsk.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.Volinsk.setStyleSheet("QPushButton {\n"
"background-color: #333333;\n"
"border-radius: 10px;\n"
"\n"
"font-family: Poppins-Medium;\n"
"font-size: 16px;\n"
"color: #fff;\n"
"line-height: 1.2;\n"
"}\n"
"QPushButton::before {\n"
"  content: \"\";\n"
"  display: block;\n"
"  position: absolute;\n"
"  z-index: -1;\n"
"  width: 100%;\n"
"  height: 100%;\n"
"  border-radius: 10px;\n"
"  top: 0;\n"
"  left: 0;\n"
"  background: #a64bf4;\n"
"  background: -webkit-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: -o-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: -moz-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  opacity: 0;\n"
"  -webkit-transition: all 0.4s;\n"
"  -o-transition: all 0.4s;\n"
"  -moz-transition: all 0.4s;\n"
"  transition: all 0.4s;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"  background-color: #545454;\n"
"}\n")
        self.Volinsk.setObjectName("Volinsk")
        self.Dnipropentrovsk = QtWidgets.QPushButton(SelectObl)
        self.Dnipropentrovsk.setGeometry(QtCore.QRect(130, 210, 331, 31))
        self.Dnipropentrovsk.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.Dnipropentrovsk.setStyleSheet("QPushButton {\n"
"background-color: #333333;\n"
"border-radius: 10px;\n"
"\n"
"font-family: Poppins-Medium;\n"
"font-size: 16px;\n"
"color: #fff;\n"
"line-height: 1.2;\n"
"}\n"
"QPushButton::before {\n"
"  content: \"\";\n"
"  display: block;\n"
"  position: absolute;\n"
"  z-index: -1;\n"
"  width: 100%;\n"
"  height: 100%;\n"
"  border-radius: 10px;\n"
"  top: 0;\n"
"  left: 0;\n"
"  background: #a64bf4;\n"
"  background: -webkit-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: -o-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: -moz-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  opacity: 0;\n"
"  -webkit-transition: all 0.4s;\n"
"  -o-transition: all 0.4s;\n"
"  -moz-transition: all 0.4s;\n"
"  transition: all 0.4s;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"  background-color: #545454;\n"
"}\n")
        self.Dnipropentrovsk.setObjectName("Dnipropentrovsk")
        self.Donteska = QtWidgets.QPushButton(SelectObl)
        self.Donteska.setGeometry(QtCore.QRect(130, 250, 331, 31))
        self.Donteska.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.Donteska.setStyleSheet("QPushButton {\n"
"background-color: #333333;\n"
"border-radius: 10px;\n"
"\n"
"font-family: Poppins-Medium;\n"
"font-size: 16px;\n"
"color: #fff;\n"
"line-height: 1.2;\n"
"}\n"
"QPushButton::before {\n"
"  content: \"\";\n"
"  display: block;\n"
"  position: absolute;\n"
"  z-index: -1;\n"
"  width: 100%;\n"
"  height: 100%;\n"
"  border-radius: 10px;\n"
"  top: 0;\n"
"  left: 0;\n"
"  background: #a64bf4;\n"
"  background: -webkit-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: -o-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: -moz-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  opacity: 0;\n"
"  -webkit-transition: all 0.4s;\n"
"  -o-transition: all 0.4s;\n"
"  -moz-transition: all 0.4s;\n"
"  transition: all 0.4s;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"  background-color: #545454;\n"
"}\n")
        self.Donteska.setObjectName("Donteska")
        self.Zhitomirska = QtWidgets.QPushButton(SelectObl)
        self.Zhitomirska.setGeometry(QtCore.QRect(130, 290, 331, 31))
        self.Zhitomirska.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.Zhitomirska.setStyleSheet("QPushButton {\n"
"background-color: #333333;\n"
"border-radius: 10px;\n"
"\n"
"font-family: Poppins-Medium;\n"
"font-size: 16px;\n"
"color: #fff;\n"
"line-height: 1.2;\n"
"}\n"
"QPushButton::before {\n"
"  content: \"\";\n"
"  display: block;\n"
"  position: absolute;\n"
"  z-index: -1;\n"
"  width: 100%;\n"
"  height: 100%;\n"
"  border-radius: 10px;\n"
"  top: 0;\n"
"  left: 0;\n"
"  background: #a64bf4;\n"
"  background: -webkit-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: -o-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: -moz-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  opacity: 0;\n"
"  -webkit-transition: all 0.4s;\n"
"  -o-transition: all 0.4s;\n"
"  -moz-transition: all 0.4s;\n"
"  transition: all 0.4s;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"  background-color: #545454;\n"
"}\n")
        self.Zhitomirska.setObjectName("Zhitomirska")
        self.Zakarpatska = QtWidgets.QPushButton(SelectObl)
        self.Zakarpatska.setGeometry(QtCore.QRect(130, 330, 331, 31))
        self.Zakarpatska.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.Zakarpatska.setStyleSheet("QPushButton {\n"
"background-color: #333333;\n"
"border-radius: 10px;\n"
"\n"
"font-family: Poppins-Medium;\n"
"font-size: 16px;\n"
"color: #fff;\n"
"line-height: 1.2;\n"
"}\n"
"QPushButton::before {\n"
"  content: \"\";\n"
"  display: block;\n"
"  position: absolute;\n"
"  z-index: -1;\n"
"  width: 100%;\n"
"  height: 100%;\n"
"  border-radius: 10px;\n"
"  top: 0;\n"
"  left: 0;\n"
"  background: #a64bf4;\n"
"  background: -webkit-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: -o-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: -moz-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  opacity: 0;\n"
"  -webkit-transition: all 0.4s;\n"
"  -o-transition: all 0.4s;\n"
"  -moz-transition: all 0.4s;\n"
"  transition: all 0.4s;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"  background-color: #545454;\n"
"}\n")
        self.Zakarpatska.setObjectName("Zakarpatska")
        self.Zaporizka = QtWidgets.QPushButton(SelectObl)
        self.Zaporizka.setGeometry(QtCore.QRect(130, 370, 331, 31))
        self.Zaporizka.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.Zaporizka.setStyleSheet("QPushButton {\n"
"background-color: #333333;\n"
"border-radius: 10px;\n"
"\n"
"font-family: Poppins-Medium;\n"
"font-size: 16px;\n"
"color: #fff;\n"
"line-height: 1.2;\n"
"}\n"
"QPushButton::before {\n"
"  content: \"\";\n"
"  display: block;\n"
"  position: absolute;\n"
"  z-index: -1;\n"
"  width: 100%;\n"
"  height: 100%;\n"
"  border-radius: 10px;\n"
"  top: 0;\n"
"  left: 0;\n"
"  background: #a64bf4;\n"
"  background: -webkit-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: -o-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: -moz-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  opacity: 0;\n"
"  -webkit-transition: all 0.4s;\n"
"  -o-transition: all 0.4s;\n"
"  -moz-transition: all 0.4s;\n"
"  transition: all 0.4s;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"  background-color: #545454;\n"
"}\n")
        self.Zaporizka.setObjectName("Zaporizka")
        self.Ivanofrankivska = QtWidgets.QPushButton(SelectObl)
        self.Ivanofrankivska.setGeometry(QtCore.QRect(130, 410, 331, 31))
        self.Ivanofrankivska.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.Ivanofrankivska.setStyleSheet("QPushButton {\n"
"background-color: #333333;\n"
"border-radius: 10px;\n"
"\n"
"font-family: Poppins-Medium;\n"
"font-size: 16px;\n"
"color: #fff;\n"
"line-height: 1.2;\n"
"}\n"
"QPushButton::before {\n"
"  content: \"\";\n"
"  display: block;\n"
"  position: absolute;\n"
"  z-index: -1;\n"
"  width: 100%;\n"
"  height: 100%;\n"
"  border-radius: 10px;\n"
"  top: 0;\n"
"  left: 0;\n"
"  background: #a64bf4;\n"
"  background: -webkit-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: -o-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: -moz-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  opacity: 0;\n"
"  -webkit-transition: all 0.4s;\n"
"  -o-transition: all 0.4s;\n"
"  -moz-transition: all 0.4s;\n"
"  transition: all 0.4s;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"  background-color: #545454;\n"
"}\n")
        self.Ivanofrankivska.setObjectName("Ivanofrankivska")
        self.Kievska = QtWidgets.QPushButton(SelectObl)
        self.Kievska.setGeometry(QtCore.QRect(130, 450, 331, 31))
        self.Kievska.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.Kievska.setStyleSheet("QPushButton {\n"
"background-color: #333333;\n"
"border-radius: 10px;\n"
"\n"
"font-family: Poppins-Medium;\n"
"font-size: 16px;\n"
"color: #fff;\n"
"line-height: 1.2;\n"
"}\n"
"QPushButton::before {\n"
"  content: \"\";\n"
"  display: block;\n"
"  position: absolute;\n"
"  z-index: -1;\n"
"  width: 100%;\n"
"  height: 100%;\n"
"  border-radius: 10px;\n"
"  top: 0;\n"
"  left: 0;\n"
"  background: #a64bf4;\n"
"  background: -webkit-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: -o-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: -moz-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  opacity: 0;\n"
"  -webkit-transition: all 0.4s;\n"
"  -o-transition: all 0.4s;\n"
"  -moz-transition: all 0.4s;\n"
"  transition: all 0.4s;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"  background-color: #545454;\n"
"}\n")
        self.Kievska.setObjectName("Kievska")
        self.Kirovogradska = QtWidgets.QPushButton(SelectObl)
        self.Kirovogradska.setGeometry(QtCore.QRect(130, 490, 331, 31))
        self.Kirovogradska.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.Kirovogradska.setStyleSheet("QPushButton {\n"
"background-color: #333333;\n"
"border-radius: 10px;\n"
"\n"
"font-family: Poppins-Medium;\n"
"font-size: 16px;\n"
"color: #fff;\n"
"line-height: 1.2;\n"
"}\n"
"QPushButton::before {\n"
"  content: \"\";\n"
"  display: block;\n"
"  position: absolute;\n"
"  z-index: -1;\n"
"  width: 100%;\n"
"  height: 100%;\n"
"  border-radius: 10px;\n"
"  top: 0;\n"
"  left: 0;\n"
"  background: #a64bf4;\n"
"  background: -webkit-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: -o-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: -moz-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  opacity: 0;\n"
"  -webkit-transition: all 0.4s;\n"
"  -o-transition: all 0.4s;\n"
"  -moz-transition: all 0.4s;\n"
"  transition: all 0.4s;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"  background-color: #545454;\n"
"}\n")
        self.Kirovogradska.setObjectName("Kirovogradska")
        self.Luganska = QtWidgets.QPushButton(SelectObl)
        self.Luganska.setGeometry(QtCore.QRect(130, 530, 331, 31))
        self.Luganska.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.Luganska.setStyleSheet("QPushButton {\n"
"background-color: #333333;\n"
"border-radius: 10px;\n"
"\n"
"font-family: Poppins-Medium;\n"
"font-size: 16px;\n"
"color: #fff;\n"
"line-height: 1.2;\n"
"}\n"
"QPushButton::before {\n"
"  content: \"\";\n"
"  display: block;\n"
"  position: absolute;\n"
"  z-index: -1;\n"
"  width: 100%;\n"
"  height: 100%;\n"
"  border-radius: 10px;\n"
"  top: 0;\n"
"  left: 0;\n"
"  background: #a64bf4;\n"
"  background: -webkit-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: -o-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: -moz-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  opacity: 0;\n"
"  -webkit-transition: all 0.4s;\n"
"  -o-transition: all 0.4s;\n"
"  -moz-transition: all 0.4s;\n"
"  transition: all 0.4s;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"  background-color: #545454;\n"
"}\n")
        self.Luganska.setObjectName("Luganska")
        self.Lvivska = QtWidgets.QPushButton(SelectObl)
        self.Lvivska.setGeometry(QtCore.QRect(130, 570, 331, 31))
        self.Lvivska.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.Lvivska.setStyleSheet("QPushButton {\n"
"background-color: #333333;\n"
"border-radius: 10px;\n"
"\n"
"font-family: Poppins-Medium;\n"
"font-size: 16px;\n"
"color: #fff;\n"
"line-height: 1.2;\n"
"}\n"
"QPushButton::before {\n"
"  content: \"\";\n"
"  display: block;\n"
"  position: absolute;\n"
"  z-index: -1;\n"
"  width: 100%;\n"
"  height: 100%;\n"
"  border-radius: 10px;\n"
"  top: 0;\n"
"  left: 0;\n"
"  background: #a64bf4;\n"
"  background: -webkit-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: -o-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: -moz-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  opacity: 0;\n"
"  -webkit-transition: all 0.4s;\n"
"  -o-transition: all 0.4s;\n"
"  -moz-transition: all 0.4s;\n"
"  transition: all 0.4s;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"  background-color: #545454;\n"
"}\n")
        self.Lvivska.setObjectName("Lvivska")
        self.Mikolaevska = QtWidgets.QPushButton(SelectObl)
        self.Mikolaevska.setGeometry(QtCore.QRect(130, 610, 331, 31))
        self.Mikolaevska.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.Mikolaevska.setStyleSheet("QPushButton {\n"
"background-color: #333333;\n"
"border-radius: 10px;\n"
"\n"
"font-family: Poppins-Medium;\n"
"font-size: 16px;\n"
"color: #fff;\n"
"line-height: 1.2;\n"
"}\n"
"QPushButton::before {\n"
"  content: \"\";\n"
"  display: block;\n"
"  position: absolute;\n"
"  z-index: -1;\n"
"  width: 100%;\n"
"  height: 100%;\n"
"  border-radius: 10px;\n"
"  top: 0;\n"
"  left: 0;\n"
"  background: #a64bf4;\n"
"  background: -webkit-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: -o-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: -moz-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  opacity: 0;\n"
"  -webkit-transition: all 0.4s;\n"
"  -o-transition: all 0.4s;\n"
"  -moz-transition: all 0.4s;\n"
"  transition: all 0.4s;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"  background-color: #545454;\n"
"}\n")
        self.Mikolaevska.setObjectName("Mikolaevska")
        self.Sumska = QtWidgets.QPushButton(SelectObl)
        self.Sumska.setGeometry(QtCore.QRect(510, 370, 331, 31))
        self.Sumska.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.Sumska.setStyleSheet("QPushButton {\n"
"background-color: #333333;\n"
"border-radius: 10px;\n"
"\n"
"font-family: Poppins-Medium;\n"
"font-size: 16px;\n"
"color: #fff;\n"
"line-height: 1.2;\n"
"}\n"
"QPushButton::before {\n"
"  content: \"\";\n"
"  display: block;\n"
"  position: absolute;\n"
"  z-index: -1;\n"
"  width: 100%;\n"
"  height: 100%;\n"
"  border-radius: 10px;\n"
"  top: 0;\n"
"  left: 0;\n"
"  background: #a64bf4;\n"
"  background: -webkit-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: -o-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: -moz-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  opacity: 0;\n"
"  -webkit-transition: all 0.4s;\n"
"  -o-transition: all 0.4s;\n"
"  -moz-transition: all 0.4s;\n"
"  transition: all 0.4s;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"  background-color: #545454;\n"
"}\n")
        self.Sumska.setObjectName("Sumska")
        self.Hmelnitska = QtWidgets.QPushButton(SelectObl)
        self.Hmelnitska.setGeometry(QtCore.QRect(510, 490, 331, 31))
        self.Hmelnitska.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.Hmelnitska.setStyleSheet("QPushButton {\n"
"background-color: #333333;\n"
"border-radius: 10px;\n"
"\n"
"font-family: Poppins-Medium;\n"
"font-size: 16px;\n"
"color: #fff;\n"
"line-height: 1.2;\n"
"}\n"
"QPushButton::before {\n"
"  content: \"\";\n"
"  display: block;\n"
"  position: absolute;\n"
"  z-index: -1;\n"
"  width: 100%;\n"
"  height: 100%;\n"
"  border-radius: 10px;\n"
"  top: 0;\n"
"  left: 0;\n"
"  background: #a64bf4;\n"
"  background: -webkit-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: -o-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: -moz-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  opacity: 0;\n"
"  -webkit-transition: all 0.4s;\n"
"  -o-transition: all 0.4s;\n"
"  -moz-transition: all 0.4s;\n"
"  transition: all 0.4s;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"  background-color: #545454;\n"
"}\n")
        self.Hmelnitska.setObjectName("Hmelnitska")
        self.Odeska = QtWidgets.QPushButton(SelectObl)
        self.Odeska.setGeometry(QtCore.QRect(510, 210, 331, 31))
        self.Odeska.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.Odeska.setStyleSheet("QPushButton {\n"
"background-color: #333333;\n"
"border-radius: 10px;\n"
"\n"
"font-family: Poppins-Medium;\n"
"font-size: 16px;\n"
"color: #fff;\n"
"line-height: 1.2;\n"
"}\n"
"QPushButton::before {\n"
"  content: \"\";\n"
"  display: block;\n"
"  position: absolute;\n"
"  z-index: -1;\n"
"  width: 100%;\n"
"  height: 100%;\n"
"  border-radius: 10px;\n"
"  top: 0;\n"
"  left: 0;\n"
"  background: #a64bf4;\n"
"  background: -webkit-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: -o-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: -moz-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  opacity: 0;\n"
"  -webkit-transition: all 0.4s;\n"
"  -o-transition: all 0.4s;\n"
"  -moz-transition: all 0.4s;\n"
"  transition: all 0.4s;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"  background-color: #545454;\n"
"}\n")
        self.Odeska.setObjectName("Odeska")
        self.Ternopilska = QtWidgets.QPushButton(SelectObl)
        self.Ternopilska.setGeometry(QtCore.QRect(510, 410, 331, 31))
        self.Ternopilska.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.Ternopilska.setStyleSheet("QPushButton {\n"
"background-color: #333333;\n"
"border-radius: 10px;\n"
"\n"
"font-family: Poppins-Medium;\n"
"font-size: 16px;\n"
"color: #fff;\n"
"line-height: 1.2;\n"
"}\n"
"QPushButton::before {\n"
"  content: \"\";\n"
"  display: block;\n"
"  position: absolute;\n"
"  z-index: -1;\n"
"  width: 100%;\n"
"  height: 100%;\n"
"  border-radius: 10px;\n"
"  top: 0;\n"
"  left: 0;\n"
"  background: #a64bf4;\n"
"  background: -webkit-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: -o-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: -moz-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  opacity: 0;\n"
"  -webkit-transition: all 0.4s;\n"
"  -o-transition: all 0.4s;\n"
"  -moz-transition: all 0.4s;\n"
"  transition: all 0.4s;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"  background-color: #545454;\n"
"}\n")
        self.Ternopilska.setObjectName("Ternopilska")
        self.Hersonska = QtWidgets.QPushButton(SelectObl)
        self.Hersonska.setGeometry(QtCore.QRect(510, 450, 331, 31))
        self.Hersonska.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.Hersonska.setStyleSheet("QPushButton {\n"
"background-color: #333333;\n"
"border-radius: 10px;\n"
"\n"
"font-family: Poppins-Medium;\n"
"font-size: 16px;\n"
"color: #fff;\n"
"line-height: 1.2;\n"
"}\n"
"QPushButton::before {\n"
"  content: \"\";\n"
"  display: block;\n"
"  position: absolute;\n"
"  z-index: -1;\n"
"  width: 100%;\n"
"  height: 100%;\n"
"  border-radius: 10px;\n"
"  top: 0;\n"
"  left: 0;\n"
"  background: #a64bf4;\n"
"  background: -webkit-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: -o-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: -moz-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  opacity: 0;\n"
"  -webkit-transition: all 0.4s;\n"
"  -o-transition: all 0.4s;\n"
"  -moz-transition: all 0.4s;\n"
"  transition: all 0.4s;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"  background-color: #545454;\n"
"}\n")
        self.Hersonska.setObjectName("Hersonska")
        self.Harkivska = QtWidgets.QPushButton(SelectObl)
        self.Harkivska.setGeometry(QtCore.QRect(510, 170, 331, 31))
        self.Harkivska.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.Harkivska.setStyleSheet("QPushButton {\n"
"background-color: #333333;\n"
"border-radius: 10px;\n"
"\n"
"font-family: Poppins-Medium;\n"
"font-size: 16px;\n"
"color: #fff;\n"
"line-height: 1.2;\n"
"}\n"
"QPushButton::before {\n"
"  content: \"\";\n"
"  display: block;\n"
"  position: absolute;\n"
"  z-index: -1;\n"
"  width: 100%;\n"
"  height: 100%;\n"
"  border-radius: 10px;\n"
"  top: 0;\n"
"  left: 0;\n"
"  background: #a64bf4;\n"
"  background: -webkit-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: -o-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: -moz-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  opacity: 0;\n"
"  -webkit-transition: all 0.4s;\n"
"  -o-transition: all 0.4s;\n"
"  -moz-transition: all 0.4s;\n"
"  transition: all 0.4s;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"  background-color: #545454;\n"
"}\n")
        self.Harkivska.setObjectName("Harkivska")
        self.Chekaska = QtWidgets.QPushButton(SelectObl)
        self.Chekaska.setGeometry(QtCore.QRect(510, 530, 331, 31))
        self.Chekaska.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.Chekaska.setStyleSheet("QPushButton {\n"
"background-color: #333333;\n"
"border-radius: 10px;\n"
"\n"
"font-family: Poppins-Medium;\n"
"font-size: 16px;\n"
"color: #fff;\n"
"line-height: 1.2;\n"
"}\n"
"QPushButton::before {\n"
"  content: \"\";\n"
"  display: block;\n"
"  position: absolute;\n"
"  z-index: -1;\n"
"  width: 100%;\n"
"  height: 100%;\n"
"  border-radius: 10px;\n"
"  top: 0;\n"
"  left: 0;\n"
"  background: #a64bf4;\n"
"  background: -webkit-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: -o-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: -moz-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  opacity: 0;\n"
"  -webkit-transition: all 0.4s;\n"
"  -o-transition: all 0.4s;\n"
"  -moz-transition: all 0.4s;\n"
"  transition: all 0.4s;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"  background-color: #545454;\n"
"}\n")
        self.Chekaska.setObjectName("Chekaska")
        self.Chernivetksa = QtWidgets.QPushButton(SelectObl)
        self.Chernivetksa.setGeometry(QtCore.QRect(510, 570, 331, 31))
        self.Chernivetksa.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.Chernivetksa.setStyleSheet("QPushButton {\n"
"background-color: #333333;\n"
"border-radius: 10px;\n"
"\n"
"font-family: Poppins-Medium;\n"
"font-size: 16px;\n"
"color: #fff;\n"
"line-height: 1.2;\n"
"}\n"
"QPushButton::before {\n"
"  content: \"\";\n"
"  display: block;\n"
"  position: absolute;\n"
"  z-index: -1;\n"
"  width: 100%;\n"
"  height: 100%;\n"
"  border-radius: 10px;\n"
"  top: 0;\n"
"  left: 0;\n"
"  background: #a64bf4;\n"
"  background: -webkit-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: -o-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: -moz-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  opacity: 0;\n"
"  -webkit-transition: all 0.4s;\n"
"  -o-transition: all 0.4s;\n"
"  -moz-transition: all 0.4s;\n"
"  transition: all 0.4s;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"  background-color: #545454;\n"
"}\n")
        self.Chernivetksa.setObjectName("Chernivetksa")
        self.Rivnenska = QtWidgets.QPushButton(SelectObl)
        self.Rivnenska.setGeometry(QtCore.QRect(510, 290, 331, 31))
        self.Rivnenska.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.Rivnenska.setStyleSheet("QPushButton {\n"
"background-color: #333333;\n"
"border-radius: 10px;\n"
"\n"
"font-family: Poppins-Medium;\n"
"font-size: 16px;\n"
"color: #fff;\n"
"line-height: 1.2;\n"
"}\n"
"QPushButton::before {\n"
"  content: \"\";\n"
"  display: block;\n"
"  position: absolute;\n"
"  z-index: -1;\n"
"  width: 100%;\n"
"  height: 100%;\n"
"  border-radius: 10px;\n"
"  top: 0;\n"
"  left: 0;\n"
"  background: #a64bf4;\n"
"  background: -webkit-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: -o-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: -moz-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  opacity: 0;\n"
"  -webkit-transition: all 0.4s;\n"
"  -o-transition: all 0.4s;\n"
"  -moz-transition: all 0.4s;\n"
"  transition: all 0.4s;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"  background-color: #545454;\n"
"}\n")
        self.Rivnenska.setObjectName("Rivnenska")
        self.Chernikibska = QtWidgets.QPushButton(SelectObl)
        self.Chernikibska.setGeometry(QtCore.QRect(510, 610, 331, 31))
        self.Chernikibska.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.Chernikibska.setStyleSheet("QPushButton {\n"
"background-color: #333333;\n"
"border-radius: 10px;\n"
"\n"
"font-family: Poppins-Medium;\n"
"font-size: 16px;\n"
"color: #fff;\n"
"line-height: 1.2;\n"
"}\n"
"QPushButton::before {\n"
"  content: \"\";\n"
"  display: block;\n"
"  position: absolute;\n"
"  z-index: -1;\n"
"  width: 100%;\n"
"  height: 100%;\n"
"  border-radius: 10px;\n"
"  top: 0;\n"
"  left: 0;\n"
"  background: #a64bf4;\n"
"  background: -webkit-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: -o-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: -moz-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  opacity: 0;\n"
"  -webkit-transition: all 0.4s;\n"
"  -o-transition: all 0.4s;\n"
"  -moz-transition: all 0.4s;\n"
"  transition: all 0.4s;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"  background-color: #545454;\n"
"}\n")
        self.Chernikibska.setObjectName("Chernikibska")
        self.Poltavska = QtWidgets.QPushButton(SelectObl)
        self.Poltavska.setGeometry(QtCore.QRect(510, 250, 331, 31))
        self.Poltavska.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.Poltavska.setStyleSheet("QPushButton {\n"
"background-color: #333333;\n"
"border-radius: 10px;\n"
"\n"
"font-family: Poppins-Medium;\n"
"font-size: 16px;\n"
"color: #fff;\n"
"line-height: 1.2;\n"
"}\n"
"QPushButton::before {\n"
"  content: \"\";\n"
"  display: block;\n"
"  position: absolute;\n"
"  z-index: -1;\n"
"  width: 100%;\n"
"  height: 100%;\n"
"  border-radius: 10px;\n"
"  top: 0;\n"
"  left: 0;\n"
"  background: #a64bf4;\n"
"  background: -webkit-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: -o-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: -moz-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  opacity: 0;\n"
"  -webkit-transition: all 0.4s;\n"
"  -o-transition: all 0.4s;\n"
"  -moz-transition: all 0.4s;\n"
"  transition: all 0.4s;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"  background-color: #545454;\n"
"}\n")
        self.Poltavska.setObjectName("Poltavska")
        self.mKiev = QtWidgets.QPushButton(SelectObl)
        self.mKiev.setGeometry(QtCore.QRect(510, 130, 331, 31))
        self.mKiev.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.mKiev.setStyleSheet("QPushButton {\n"
"background-color: #333333;\n"
"border-radius: 10px;\n"
"\n"
"font-family: Poppins-Medium;\n"
"font-size: 16px;\n"
"color: #fff;\n"
"line-height: 1.2;\n"
"}\n"
"QPushButton::before {\n"
"  content: \"\";\n"
"  display: block;\n"
"  position: absolute;\n"
"  z-index: -1;\n"
"  width: 100%;\n"
"  height: 100%;\n"
"  border-radius: 10px;\n"
"  top: 0;\n"
"  left: 0;\n"
"  background: #a64bf4;\n"
"  background: -webkit-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: -o-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: -moz-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  opacity: 0;\n"
"  -webkit-transition: all 0.4s;\n"
"  -o-transition: all 0.4s;\n"
"  -moz-transition: all 0.4s;\n"
"  transition: all 0.4s;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"  background-color: #545454;\n"
"}\n")
        self.mKiev.setObjectName("mKiev")
        self.Vinitska = QtWidgets.QPushButton(SelectObl)
        self.Vinitska.setGeometry(QtCore.QRect(510, 330, 331, 31))
        self.Vinitska.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.Vinitska.setStyleSheet("QPushButton {\n"
"background-color: #333333;\n"
"border-radius: 10px;\n"
"\n"
"font-family: Poppins-Medium;\n"
"font-size: 16px;\n"
"color: #fff;\n"
"line-height: 1.2;\n"
"}\n"
"QPushButton::before {\n"
"  content: \"\";\n"
"  display: block;\n"
"  position: absolute;\n"
"  z-index: -1;\n"
"  width: 100%;\n"
"  height: 100%;\n"
"  border-radius: 10px;\n"
"  top: 0;\n"
"  left: 0;\n"
"  background: #a64bf4;\n"
"  background: -webkit-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: -o-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: -moz-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  opacity: 0;\n"
"  -webkit-transition: all 0.4s;\n"
"  -o-transition: all 0.4s;\n"
"  -moz-transition: all 0.4s;\n"
"  transition: all 0.4s;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"  background-color: #545454;\n"
"}\n")
        self.Vinitska.setObjectName("Vinitska")
        self.Ukraine = QtWidgets.QPushButton(SelectObl)
        self.Ukraine.setGeometry(QtCore.QRect(170, 660, 621, 71))
        self.Ukraine.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.Ukraine.setStyleSheet("QPushButton {\n"
"background-color: #333333;\n"
"border-radius: 10px;\n"
"\n"
"font-family: Poppins-Medium;\n"
"font-size: 16px;\n"
"color: #fff;\n"
"line-height: 1.2;\n"
"}\n"
"QPushButton::before {\n"
"  content: \"\";\n"
"  display: block;\n"
"  position: absolute;\n"
"  z-index: -1;\n"
"  width: 100%;\n"
"  height: 100%;\n"
"  border-radius: 10px;\n"
"  top: 0;\n"
"  left: 0;\n"
"  background: #a64bf4;\n"
"  background: -webkit-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: -o-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: -moz-linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  background: linear-gradient(45deg, #00dbde, #fc00ff);\n"
"  opacity: 0;\n"
"  -webkit-transition: all 0.4s;\n"
"  -o-transition: all 0.4s;\n"
"  -moz-transition: all 0.4s;\n"
"  transition: all 0.4s;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"  background-color: #545454;\n"
"}\n")

        self.Ukraine.setObjectName("Ukraine")
        self.label = QtWidgets.QLabel(SelectObl)
        self.label.setGeometry(QtCore.QRect(140, 60, 301, 31))
        self.label.setStyleSheet("font-size: 25px;\n"
        "color: #333333;\n"
        "font-family: arial;\n"
        "font-weight: bold;")
        self.label.setObjectName("label")
        self.frame = QtWidgets.QFrame(SelectObl)
        self.frame.setGeometry(QtCore.QRect(-1, -1, 973, 773))
        self.frame.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.frame.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frame.setObjectName("frame")
        self.frame.raise_()
        self.Vintis.raise_()
        self.Volinsk.raise_()
        self.Dnipropentrovsk.raise_()
        self.Donteska.raise_()
        self.Zhitomirska.raise_()
        self.Zakarpatska.raise_()
        self.Zaporizka.raise_()
        self.Ivanofrankivska.raise_()
        self.Kievska.raise_()
        self.Kirovogradska.raise_()
        self.Luganska.raise_()
        self.Lvivska.raise_()
        self.Mikolaevska.raise_()
        self.Sumska.raise_()
        self.Hmelnitska.raise_()
        self.Odeska.raise_()
        self.Ternopilska.raise_()
        self.Hersonska.raise_()
        self.Harkivska.raise_()
        self.Chekaska.raise_()
        self.Chernivetksa.raise_()
        self.Rivnenska.raise_()
        self.Chernikibska.raise_()
        self.Poltavska.raise_()
        self.mKiev.raise_()
        self.Vinitska.raise_()
        self.Ukraine.raise_()
        self.label.raise_()

        self.retranslateUi(SelectObl)
        QtCore.QMetaObject.connectSlotsByName(SelectObl)

    def retranslateUi(self, SelectObl):
        _translate = QtCore.QCoreApplication.translate
        SelectObl.setWindowTitle(_translate("SelectObl", "Sailor Sender"))
        self.Vintis.setText(_translate("SelectObl", "Вінницька область"))
        self.Volinsk.setText(_translate("SelectObl", "Волинська область"))
        self.Dnipropentrovsk.setText(_translate("SelectObl", "Дніпропетровська область"))
        self.Donteska.setText(_translate("SelectObl", "Донецька область"))
        self.Zhitomirska.setText(_translate("SelectObl", "Житомирська область"))
        self.Zakarpatska.setText(_translate("SelectObl", "Закарпатська область"))
        self.Zaporizka.setText(_translate("SelectObl", "Запорізька область"))
        self.Ivanofrankivska.setText(_translate("SelectObl", "Івано-Франківська область"))
        self.Kievska.setText(_translate("SelectObl", "Київська область"))
        self.Kirovogradska.setText(_translate("SelectObl", "Кіровоградська область"))
        self.Luganska.setText(_translate("SelectObl", "Луганська область"))
        self.Lvivska.setText(_translate("SelectObl", "Львівська область"))
        self.Mikolaevska.setText(_translate("SelectObl", "Миколаївська область"))
        self.Sumska.setText(_translate("SelectObl", "Сумська область"))
        self.Hmelnitska.setText(_translate("SelectObl", "Хмельницька область"))
        self.Odeska.setText(_translate("SelectObl", "Одеська область"))
        self.Ternopilska.setText(_translate("SelectObl", "Тернопільська область"))
        self.Hersonska.setText(_translate("SelectObl", "Херсонська область"))
        self.Harkivska.setText(_translate("SelectObl", "Харківська область"))
        self.Chekaska.setText(_translate("SelectObl", "Черкаська область"))
        self.Chernivetksa.setText(_translate("SelectObl", "Чернівецька область"))
        self.Rivnenska.setText(_translate("SelectObl", "Рівненська область"))
        self.Chernikibska.setText(_translate("SelectObl", "Чернігівська область"))
        self.Poltavska.setText(_translate("SelectObl", "Полтавська область"))
        self.mKiev.setText(_translate("SelectObl", "Місто Київ"))
        self.Vinitska.setText(_translate("SelectObl", "Вінницька область"))
        self.Ukraine.setText(_translate("SelectObl", "Вся Україна"))
        self.label.setText(_translate("SelectObl", "Оберіть область:"))
     
        